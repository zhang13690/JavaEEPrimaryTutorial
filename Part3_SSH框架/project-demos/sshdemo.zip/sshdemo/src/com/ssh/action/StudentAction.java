package com.ssh.action;

import com.opensymphony.xwork2.ActionSupport;
import com.ssh.entity.Student;
import com.ssh.service.IStudentService;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;

import javax.annotation.Resource;

@Controller // Action也得加入容器中
@Scope("prototype")
public class StudentAction extends ActionSupport {
    @Resource
    private IStudentService studentService; // 维护service

    // 接收的参数
    private Student student;
    private int id;
    private String name;
    // 下面是处理的方法。共用了上述的参数。可以按需编写。
    public String addStudent() {
        studentService.add(student);
        return SUCCESS;
    }
    public String deleteStudent() {
        studentService.delete(id);
        return SUCCESS;
    }
    public String updateStudent() {
        studentService.update(student);
        return SUCCESS;
    }
    public String findById() {
        studentService.findById(id);
        return SUCCESS;
    }
    public String findAll() {
        studentService.findAll();
        return SUCCESS;
    }
    public String findByName() {
        studentService.findByName(name);
        return SUCCESS;
    }

    // getter和setter
    public Student getStudent() {
        return student;
    }

    public void setStudent(Student student) {
        this.student = student;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
