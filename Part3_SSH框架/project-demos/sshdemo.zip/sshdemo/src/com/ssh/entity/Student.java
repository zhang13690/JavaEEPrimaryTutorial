package com.ssh.entity;

import java.util.Date;

public class Student {
    private int id;
    private String name;
    private Date entranceTime;
    public Student() {}
    // 其他构造器、setter/getter/toString等

    public Student(int id, String name, Date entranceTime) {
        this.id = id;
        this.name = name;
        this.entranceTime = entranceTime;
    }

    @Override
    public String toString() {
        return "Student{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", entranceTime=" + entranceTime +
                '}';
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Date getEntranceTime() {
        return entranceTime;
    }

    public void setEntranceTime(Date entranceTime) {
        this.entranceTime = entranceTime;
    }
}
