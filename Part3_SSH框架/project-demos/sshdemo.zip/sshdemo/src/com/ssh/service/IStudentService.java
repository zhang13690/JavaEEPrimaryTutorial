package com.ssh.service;

import com.ssh.entity.Student;

import java.util.List;

public interface IStudentService {

    // 添加学生
    void add(Student student);

    // 删除学生(根据id)
    void delete(int id);

    // 更新学生
    void update(Student student);

    // 查找学生
    Student findById(int id);

    // 查询所有学生
    List<Student> findAll();

    // 查询指定姓名学生
    List<Student> findByName(String name);
}
