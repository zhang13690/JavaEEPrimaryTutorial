package com.ssh.service.impl;

import com.ssh.dao.IStudentDao;
import com.ssh.entity.Student;
import com.ssh.service.IStudentService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.Date;
import java.util.List;

@Service // 加入容器
public class StudentServiceImpl implements IStudentService {
    @Resource
    private IStudentDao studentDao;

    @Override
    @Transactional(readOnly = false)
    public void add(Student student) {
        studentDao.add(student);
    }

    @Override
    @Transactional(readOnly = false)
    public void delete(int id) {
        Student student = new Student();
        student.setId(id);
        studentDao.delete(student);
    }

    @Override
    @Transactional(readOnly = false)
    public void update(Student student) {
        studentDao.update(student);
    }

    @Override
    @Transactional(readOnly = true)
    public Student findById(int id) {
        return studentDao.findById(Student.class, id);
    }

    @Override
    @Transactional(readOnly = true)
    public List<Student> findAll() {
        return studentDao.findAll(Student.class);
    }

    @Override
    @Transactional(readOnly = true)
    public List<Student> findByName(String name) {
        return studentDao.findByName(name);
    }
}
