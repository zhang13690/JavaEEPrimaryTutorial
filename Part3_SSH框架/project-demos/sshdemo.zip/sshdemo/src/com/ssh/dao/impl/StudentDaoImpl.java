package com.ssh.dao.impl;

import com.ssh.dao.IStudentDao;
import com.ssh.entity.Student;
import org.hibernate.query.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

// 该类既要继承，又要实现
@Repository
public class StudentDaoImpl extends BaseDaoImpl<Student> implements IStudentDao {
    @Override
    public List<Student> findByName(String name) {
        Query<Student> query = sessionFactory.getCurrentSession().createQuery("from Student where name = ?", Student.class);
        return query.list();
    }
}
