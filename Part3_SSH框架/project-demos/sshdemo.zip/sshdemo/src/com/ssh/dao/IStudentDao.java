package com.ssh.dao;

import com.ssh.entity.Student;

import java.util.List;

// 这里继承的泛型参数就用Student
public interface IStudentDao extends IBaseDao<Student> {
    /**
     * 按姓名查找学生
     * @param name 姓名
     * @return 学生列表
     */
    List<Student> findByName(String name);
}
