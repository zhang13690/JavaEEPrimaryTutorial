package com.ssh.dao;

import java.io.Serializable;
import java.util.List;

/**
 * 基础DAO接口提供基本操作方法的原型
 */
public interface IBaseDao<T> {
    /**
     * 添加一个对象
     * @param t 对象
     */
    void add(T t);

    /**
     * 根据主键删除对象数据
     */
    void delete(T t);

    /**
     * 更新对象数据
     * @param t 对象
     */
    void update(T t);

    /**
     * 根据主键查询对象数据
     * @param clazz 类字节码文件
     * @param id 主键
     * @return 对象
     */
    T findById(Class<T> clazz, Serializable id);

    /**
     * 查询某实体所有的数据
     * @param clazz 类字节码文件
     * @return 对象集合
     */
    List<T> findAll(Class<T> clazz);
}
