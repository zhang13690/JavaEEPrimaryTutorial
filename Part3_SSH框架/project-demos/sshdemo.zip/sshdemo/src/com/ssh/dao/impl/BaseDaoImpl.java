package com.ssh.dao.impl;

import com.ssh.dao.IBaseDao;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import javax.annotation.Resource;
import java.io.Serializable;
import java.util.List;

public class BaseDaoImpl<T> implements IBaseDao<T> {

    @Resource
    protected SessionFactory sessionFactory;

    @Override
    public void add(T t) {
        sessionFactory.getCurrentSession().save(t);
    }

    @Override
    public void delete(T t) {
        sessionFactory.getCurrentSession().delete(t);
    }

    @Override
    public void update(T t) {
        sessionFactory.getCurrentSession().update(t);
    }

    @Override
    public T findById(Class<T> clazz, Serializable id) {
        return sessionFactory.getCurrentSession().get(clazz, id);
    }

    @Override
    public List<T> findAll(Class<T> clazz) {
        Session session = sessionFactory.getCurrentSession();
        return session.createQuery("from " + clazz.getName(), clazz).list();
    }
}
