package com.hb.domain;

import java.io.Serializable;
import java.util.LinkedHashSet;
import java.util.Set;

public class Dept implements Serializable {
    private Integer deptId; // 编号
    private String name; // 部门名称
    private Set<Developer> developerSet = new LinkedHashSet<>(); // 关联的开发者

    // getter和setter
    public Integer getDeptId() {
        return deptId;
    }

    public void setDeptId(Integer deptId) {
        this.deptId = deptId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Set<Developer> getDeveloperSet() {
        return developerSet;
    }

    public void setDeveloperSet(Set<Developer> developerSet) {
        this.developerSet = developerSet;
    }
}
