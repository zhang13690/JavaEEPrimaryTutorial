package com.hb.domain;

import java.io.Serializable;
import java.util.LinkedHashSet;
import java.util.Set;

public class Developer implements Serializable {
    private Integer devId; // 开发者编号
    private String devName; // 开发者姓名
    private Dept dept; // 关联的部门
    private Set<Project> projectSet = new LinkedHashSet<>(); // 关联的项目

    // getter/setter...

    public Integer getDevId() {
        return devId;
    }

    public void setDevId(Integer devId) {
        this.devId = devId;
    }

    public String getDevName() {
        return devName;
    }

    public void setDevName(String devName) {
        this.devName = devName;
    }

    public Dept getDept() {
        return dept;
    }

    public void setDept(Dept dept) {
        this.dept = dept;
    }

    public Set<Project> getProjectSet() {
        return projectSet;
    }

    public void setProjectSet(Set<Project> projectSet) {
        this.projectSet = projectSet;
    }
}
