package com.hb.domain;

import java.io.Serializable;
import java.util.LinkedHashSet;
import java.util.Set;

public class Project implements Serializable {
    private Integer pid; // 项目主键
    private String pname; // 项目名称
    private Set<Developer> developerSet = new LinkedHashSet<>(); // 关联的开发者

    // setter/getter...
    public Integer getPid() {
        return pid;
    }

    public void setPid(Integer pid) {
        this.pid = pid;
    }

    public String getPname() {
        return pname;
    }

    public void setPname(String pname) {
        this.pname = pname;
    }

    public Set<Developer> getDeveloperSet() {
        return developerSet;
    }

    public void setDeveloperSet(Set<Developer> developerSet) {
        this.developerSet = developerSet;
    }
}
