package com.utils;

import java.io.IOException;
import java.util.Base64;

public class Base64Utils {
    // 编码字符串
    public static String encodeString(String str) throws IOException {
        return Base64.getEncoder().encodeToString(str.getBytes());
    }

    // 将Base64编码解码，并以字符串方式返回。
    public static String decodeString(String base64Str) throws IOException {
        byte[] res = Base64.getDecoder().decode(base64Str);
        return new String(res);
    }
}
