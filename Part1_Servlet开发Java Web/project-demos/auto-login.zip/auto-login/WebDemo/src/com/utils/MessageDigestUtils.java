package com.utils;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class MessageDigestUtils {
    private MessageDigestUtils() {}

    public static String encrypt(String algorithm, byte[] data, boolean isUpperCase) {
        MessageDigest messageDigest = null;
        StringBuilder sb = new StringBuilder();
        try {
            messageDigest = MessageDigest.getInstance(algorithm);
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException(e);
        }
        byte[] encByte = messageDigest.digest(data);
        for (byte b : encByte) {
            int i = 0xff & b;
            if (i < 16) {
                sb.append("0");
            }
            sb.append(Integer.toHexString(i));
        }
        return isUpperCase ? sb.toString().toUpperCase() : sb.toString(); // 因为默认就是小写的
    }
}
