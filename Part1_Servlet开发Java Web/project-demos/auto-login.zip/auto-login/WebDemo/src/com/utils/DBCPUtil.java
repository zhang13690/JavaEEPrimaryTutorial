package com.utils;

import org.apache.commons.dbcp2.BasicDataSourceFactory;

import javax.sql.DataSource;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

public class DBCPUtil {
    private static DataSource dataSource;
    static {
        try {
            // 读取配置文件，初始化数据源
            Properties props = new Properties();
            InputStream in = DBCPUtil.class.getClassLoader().getResourceAsStream("db.properties");
            props.load(in);
            // BasicDataSourceFactory.createDataSource返回的是BasicDataSource类型对象，而BasicDataSource实现了DataSource接口，因此可赋值给dataSource
            dataSource = BasicDataSourceFactory.createDataSource(props);
        } catch (Exception e) {
            throw new ExceptionInInitializerError(e);
        }

    }

    // 提供获得数据源对象的方法
    public static DataSource getDataSource() {
        return dataSource;
    }

    // 提供获得数据库连接的方法
    public static Connection getConnection() {
        try {
            return dataSource.getConnection();
        } catch (SQLException e) {
            throw new RuntimeException("获取数据库连接失败！");
        }
    }

    // 下面提供资源的释放方法，和以前的JDBCUtil中释放代码一样，但以后就不用JDBCUtil了，直接使用该类即可。
    // 需要知道的是，释放资源中，虽然代码和以前基本一致，但是调用connection.close()方法实际上是把数据库连接返回给DBCP数据库连接池，这个就是前面讲的原理，不再多说
    // 唯一需要注意的是，最后的connection不再赋值为null，因为连接对象不是被关闭了。

    /**
     * 释放资源
     * @param conn 连接资源
     * @param stmt statement资源
     * @param rs 结果集资源
     */
    public static void release(Connection conn, Statement stmt, ResultSet rs) {
        if (rs != null) {
            try {
                rs.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
            rs = null;
        }
        if (stmt != null) {
            try {
                stmt.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
            stmt = null;
        }
        if (conn != null) {
            try {
                conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
            // 注意这里不再执行conn = null; 这条语句
        }
    }

    /**
     * 释放资源
     * @param conn 连接资源
     * @param stmt statement资源
     */
    public static void release(Connection conn, Statement stmt) {
        // 这里需要调用上面的方法，最后一个参数给null即可。
        release(conn, stmt, null);
    }
}
