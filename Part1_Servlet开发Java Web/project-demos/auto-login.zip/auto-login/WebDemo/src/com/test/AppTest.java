package com.test;

import com.domain.User;
import com.service.UserService;
import com.service.impl.UserServiceImpl;
import com.utils.MessageDigestUtils;
import org.junit.Test;

public class AppTest {
    private UserService userService = new UserServiceImpl();
    @Test
    public void test() {
        User user = new User();
        user.setId(2);
        user.setUsername("张三");
        user.setPassword(MessageDigestUtils.encrypt("MD5", "123".getBytes(), false));
        userService.add(user);
    }
}
