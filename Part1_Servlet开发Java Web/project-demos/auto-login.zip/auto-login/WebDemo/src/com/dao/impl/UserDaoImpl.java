package com.dao.impl;

import com.dao.UserDao;
import com.domain.User;
import com.utils.DBCPUtil;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;

import java.sql.SQLException;

public class UserDaoImpl implements UserDao {
    QueryRunner qr = new QueryRunner(DBCPUtil.getDataSource());
    @Override
    public User find(String username, String pwd) {
        try {
            return qr.query("select * from users where username=? and password=?", new BeanHandler<User>(User.class), username, pwd);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void add(User user) {
        try {
            qr.update("insert into users values(?,?,?)", user.getId(), user.getUsername(), user.getPassword());
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
}
