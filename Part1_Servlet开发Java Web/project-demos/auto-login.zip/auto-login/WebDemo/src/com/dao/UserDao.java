package com.dao;

import com.domain.User;

public interface UserDao {
    /**
     * 根据用户名和密码返回用户信息
     * @param username 用户名
     * @param pwd 密码
     * @return 用户信息
     */
    User find(String username, String pwd);

    /**
     * 添加用户
     * @param user 用户
     */
    void add(User user);
}
