package com.controller;

import com.domain.User;
import com.service.UserService;
import com.service.impl.UserServiceImpl;
import com.utils.Base64Utils;
import com.utils.MessageDigestUtils;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;

@WebServlet(urlPatterns = "/servlet/loginServlet")
public class LoginServlet extends HttpServlet {
    private UserService userService = new UserServiceImpl();
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // 获取用户名和密码
        String username = request.getParameter("username");
        String password = request.getParameter("password"); // 这个获得的是明文密码
        // 验证登录。
        User user = userService.login(username, MessageDigestUtils.encrypt("MD5", password.getBytes(), false));
        // 登录失败
        if(user == null){
            response.getWriter().write("错误的用户名或密码");
            return;
        }
        // 登录成功，先把用户信息保存在session中
        HttpSession session = request.getSession();
        session.setAttribute("user", user);
        // 再来判断用户是否选择记住密码，如果记住密码了，还要设置cookie。
        String remember = request.getParameter("rememberPwd");
        if(remember != null){
            // 设置cookie
            Cookie c = new Cookie("loginInfo", Base64Utils.encodeString(username) + "_" + MessageDigestUtils.encrypt("MD5", password.getBytes(), false));
            c.setMaxAge(Integer.MAX_VALUE);
            c.setPath(request.getContextPath());
            response.addCookie(c);
        }
        //重定向到主页
        response.sendRedirect(request.getContextPath());
    }
}
