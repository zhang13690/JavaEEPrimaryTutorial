package com.filter;

import com.domain.User;
import com.service.UserService;
import com.service.impl.UserServiceImpl;
import com.utils.Base64Utils;

import javax.servlet.*;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

// 拦截动态资源
public class AutoLoginFilter implements Filter {
    // 用户登录的service
    private UserService userService = new UserServiceImpl();
    @Override
    public void init(FilterConfig filterConfig) throws ServletException { }

    @Override
    public void doFilter(ServletRequest req, ServletResponse resp, FilterChain chain) throws IOException, ServletException {
        // 先转换类型
        HttpServletRequest request = null;
        HttpServletResponse response = null;
        try {
            request = (HttpServletRequest) req;
            response = (HttpServletResponse) resp;
        } catch (ClassCastException e) {
            throw new RuntimeException("non-HTTP request or response");
        }
        // 通过session判断是否登录了
        HttpSession session = request.getSession();
        User sessionUser = (User) session.getAttribute("user");
        if (sessionUser == null) {
            // 当前会话中没有用户信息，则寻找Cookie。
            Cookie userInfoCookie = null;
            Cookie[] cookies = request.getCookies();
            // 下面必须判断cookies不为null。因为浏览器第一次访问网站时，过滤器获得的cookie就是null。
            // 这也是for循环中判断遍历对象是否为null的一个技巧，可以使用。这样就不需要在if中进行循环了，代码简洁一点。
            for (int i = 0; cookies!= null && i < cookies.length; i++) {
                if ("loginInfo".equals(cookies[i].getName())) {
                    userInfoCookie = cookies[i];
                }
            }
            // 如果找到了cookie，就用其中的信息进行登录
            if (userInfoCookie != null) {
                // 截取用户名和密码
                String[] userInfoStrs = userInfoCookie.getValue().split("_");
                // 注意下面的用户名进行Base64解码，密码由于cookie中本来存的就是密文，所以直接传递给service即可。
                User user = userService.login(Base64Utils.decodeString(userInfoStrs[0]), userInfoStrs[1]);
                if (user != null) {
                    // 这里就是登录成功了，那么直接把用户信息保存到session中即可，这样Servlet等动态资源就自动知道用户登录了。
                    session.setAttribute("user", user);
                }
            }
        }
        // 不管是否登录，都放行
        chain.doFilter(request, response);
    }

    @Override
    public void destroy() { }
}
