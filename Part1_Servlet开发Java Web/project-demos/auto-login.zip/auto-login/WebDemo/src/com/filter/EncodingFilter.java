package com.filter;

import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import java.io.IOException;

// 拦截所有的包含servlet的请求路径，可以把所有servlet的路径这样命名以方便拦截
//@WebFilter(urlPatterns = {"/servlet/*"})
public class EncodingFilter implements Filter {
    @Override
    public void init(FilterConfig filterConfig) throws ServletException { }

    @Override
    public void doFilter(ServletRequest req, ServletResponse resp, FilterChain chain) throws IOException, ServletException {
        // 先设置请求编码
        req.setCharacterEncoding("UTF-8");
        // 预先就设置响应编码。因为等到响应回来再设置的话，就晚了。必须在write()之前设置。
        resp.setCharacterEncoding("UTF-8");
        resp.setContentType("text/html;charset=UTF-8");
        // 放行
        chain.doFilter(req, resp);
    }

    @Override
    public void destroy() { }
}