package com.service;

import com.domain.User;

public interface UserService {
    // 登录
    User login(String username, String pwd);
    // 添加
    void add(User user);
}
