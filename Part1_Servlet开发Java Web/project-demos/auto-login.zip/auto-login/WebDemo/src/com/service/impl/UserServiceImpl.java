package com.service.impl;

import com.dao.UserDao;
import com.dao.impl.UserDaoImpl;
import com.domain.User;
import com.service.UserService;

public class UserServiceImpl implements UserService {
    private UserDao userDao = new UserDaoImpl();
    @Override
    public User login(String username, String pwd) {
        return userDao.find(username, pwd);
    }

    @Override
    public void add(User user) {
        userDao.add(user);
    }
}
